// ── SITE CONFIGURATION ────────────────────────────────────────────────────────
// Edit this file to change global settings without touching page code.

const config = {

  // Base URL for all assets (images, fonts, logos).
  // Change to 'https://kevinhaus.com/assets' when going live.
  assetsBase: 'https://test.kevinhaus.com/assets',

  // How long (in milliseconds) each still image is displayed on the home page.
  // 1000 = 1 second. Default: 3500 (3.5 seconds)
  stillHoldTime: 3500,

  // Fade transition duration for still images (ms). Keep shorter than holdTime.
  stillFadeDuration: 600,

  // Default color mode: 'light' or 'dark'
  defaultTheme: 'light',

  // Admin page password (simple client-side protection — not for sensitive data)
  adminPassword: 'changeme',

}

export default config
