import videos from '../videos.json'
import config from './site.config.js'
import navHtml from '../pages/nav.html?raw'

// ── INJECT NAV ────────────────────────────────────────────────────────────────
document.getElementById('kh-nav-mount').innerHTML = navHtml

// ── BUILD STILL POOL ──────────────────────────────────────────────────────────
// Flatten all stills from all videos into one pool,
// keeping track of which video each still belongs to.
const stillPool = []

videos.forEach(video => {
  if (video.stills && video.stills.length > 0) {
    video.stills.forEach(filename => {
      stillPool.push({
        src: `${config.assetsBase}/Stills/${filename}`,
        videoId: video.id,
        videoTitle: video.title,
      })
    })
  }
})

// Shuffle the pool (Fisher-Yates)
function shuffle(arr) {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

let pool = shuffle(stillPool)
let currentIndex = 0
let currentVideoId = null
let cycleTimer = null

// ── DOM REFS ──────────────────────────────────────────────────────────────────
const stillImg  = document.getElementById('stillImg')
const stillWrap = document.getElementById('stillWrap')

// ── PRELOAD ───────────────────────────────────────────────────────────────────
function preload(src) {
  const img = new Image()
  img.src = src
}

// ── SHOW STILL ────────────────────────────────────────────────────────────────
function showStill(index) {
  if (!pool.length) return
  const item = pool[index % pool.length]
  currentVideoId = item.videoId

  // Fade out
  stillImg.classList.add('fading')

  setTimeout(() => {
    stillImg.src  = item.src
    stillImg.alt  = item.videoTitle
    stillImg.classList.remove('fading')

    // Preload next
    const next = pool[(index + 1) % pool.length]
    preload(next.src)
  }, config.stillFadeDuration)
}

// ── CYCLE ─────────────────────────────────────────────────────────────────────
function startCycle() {
  showStill(currentIndex)

  cycleTimer = setInterval(() => {
    currentIndex = (currentIndex + 1) % pool.length

    // Reshuffle when we've gone through the full pool
    if (currentIndex === 0) pool = shuffle(stillPool)

    showStill(currentIndex)
  }, config.stillHoldTime)
}

// ── CLICK → VIDEO ─────────────────────────────────────────────────────────────
stillWrap.addEventListener('click', () => {
  if (currentVideoId !== null) {
    window.location.href = `/work.html?v=${currentVideoId}`
  }
})

// ── START ─────────────────────────────────────────────────────────────────────
// Only start if there are stills to show
if (pool.length > 0) {
  // Set CSS fade duration variable from config
  document.documentElement.style.setProperty(
    '--kh-fade-duration',
    `${config.stillFadeDuration}ms`
  )
  startCycle()
} else {
  stillWrap.style.display = 'none'
  document.querySelector('.kh-still-hint').style.display = 'none'
}

// ── LOGO SWAP on theme change ─────────────────────────────────────────────────
// Handled by main.js via data-logo-swap attributes on all logo <img> elements
